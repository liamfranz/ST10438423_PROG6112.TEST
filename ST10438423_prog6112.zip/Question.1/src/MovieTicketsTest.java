import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MovieTicketsTest {

    private final MovieTickets movieTickets = new MovieTickets();


    @Test
    void calculateTotalSales_ReturnsExpectedTotalSales() {

        int[] napoleonSales = {3000, 1500, 1600};


        int totalSales = movieTickets.TotalMovieSales(napoleonSales);


        assertEquals(3000 + 1500 + 1600, totalSales, "Total sales for Napoleon should be 6200");
    }


    @Test
    void topMovieSales_ReturnsTopMovie() {

        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {6200, 6300};


        String topMovie = movieTickets.TopMovie(movies, totalSales);


        assertEquals("Oppenheimer", topMovie, "The top performing movie should be Oppenheimer");
    }


    @Test
    void calculateTotalSales_ReturnsZeroForEmptyData() {

        int[] emptySales = {};


        int totalSales = movieTickets.TotalMovieSales(emptySales);


        assertEquals(0, totalSales, "Total sales for empty data should be 0");
    }


    @Test
    void topMovieSales_ReturnsNullForNullMovies() {

        String[] movies = null;
        int[] totalSales = null;


        String topMovie = movieTickets.TopMovie(movies, totalSales);


        assertNull(topMovie, "Top movie should be null when input is null");
    }
}
