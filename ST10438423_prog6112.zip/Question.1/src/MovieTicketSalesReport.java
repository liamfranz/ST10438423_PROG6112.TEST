public class MovieTicketSalesReport {

    public static void main(String[] args) {

        String[] movies = {"Napoleon", "Oppenheimer"};


        int[][] sales = {
                {3000, 1500, 1700},
                {3500, 1200, 1600}
        };


        int[] totalSales = new int[movies.length];


        MovieTickets movieTickets = new MovieTickets();


        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(sales[i]);
        }


        System.out.println("MOVIE TICKET SALES REPORT - 2024\n");


        System.out.println("            JAN    FEB    MAR");


        for (int i = 0; i < movies.length; i++) {
            System.out.print(movies[i] + "    ");
            for (int j = 0; j < sales[i].length; j++) {
                System.out.print(sales[i][j] + "    ");
            }
            System.out.println();
        }


        for (int i = 0; i < movies.length; i++) {
            System.out.println("Total movie ticket sales for " + movies[i] + ": " + totalSales[i]);
        }


        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("Top performing movie: " + topMovie);
    }
}
