import java.text.DecimalFormat;

public class MovieTickets {


    public static double calculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double totalTicketPrice = numberOfTickets * ticketPrice;
        double vatAmount = totalTicketPrice * 0.14;  // 14% VAT
        return totalTicketPrice + vatAmount;
    }


    public static boolean validateInput(String tickets, String price) {
        try {
            int numTickets = Integer.parseInt(tickets);
            double ticketPrice = Double.parseDouble(price);


            if (numTickets <= 0 || ticketPrice <= 0) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }


    public static String formatCurrency(double amount) {
        DecimalFormat df = new DecimalFormat("###,###.##");
        return df.format(amount);
    }
}
