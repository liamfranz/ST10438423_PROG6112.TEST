import javax.swing.*;

public class MovieTicket {
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
}
