import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MovieTicketSalesApp {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Movie Ticket Sales");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 400);


        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2, 10, 10));


        JLabel movieLabel = new JLabel("MOVIE:");
        JComboBox<String> movieComboBox = new JComboBox<>(new String[] {"Napoleon", "Oppenheimer", "Damsel"});

        JLabel ticketsLabel = new JLabel("NUMBER OF TICKETS:");
        JTextField ticketsTextField = new JTextField();

        JLabel priceLabel = new JLabel("TICKET PRICE:");
        JTextField priceTextField = new JTextField();


        JTextArea reportTextArea = new JTextArea(6, 30);
        reportTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportTextArea);


        panel.add(movieLabel);
        panel.add(movieComboBox);
        panel.add(ticketsLabel);
        panel.add(ticketsTextField);
        panel.add(priceLabel);
        panel.add(priceTextField);
        panel.add(new JLabel("TICKET REPORT:"));
        panel.add(scrollPane);


        frame.setContentPane(panel);


        JMenuBar menuBar = new JMenuBar();


        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        fileMenu.add(exitMenuItem);


        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processMenuItem = new JMenuItem("Process");
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        toolsMenu.add(processMenuItem);
        toolsMenu.add(clearMenuItem);


        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);


        frame.setJMenuBar(menuBar);


        frame.setVisible(true);


        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);  // Exit the application
            }
        });


        processMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedMovie = (String) movieComboBox.getSelectedItem();
                String tickets = ticketsTextField.getText();
                String price = priceTextField.getText();

                if (MovieTickets.validateInput(tickets, price)) {
                    int numberOfTickets = Integer.parseInt(tickets);
                    double ticketPrice = Double.parseDouble(price);


                    double totalPrice = MovieTickets.calculateTotalTicketPrice(numberOfTickets, ticketPrice);


                    String report = "MOVIE NAME: " + selectedMovie + "\n" +
                            "MOVIE TICKET PRICE: R " + MovieTickets.formatCurrency(ticketPrice) + "\n" +
                            "NUMBER OF TICKETS: " + numberOfTickets + "\n" +
                            "TOTAL TICKET PRICE (with VAT): R " + MovieTickets.formatCurrency(totalPrice);


                    reportTextArea.setText(report);


                    try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
                        writer.write("MOVIE TICKET REPORT\n");
                        writer.write("MOVIE NAME: " + selectedMovie + "\n");
                        writer.write("MOVIE TICKET PRICE: R " + MovieTickets.formatCurrency(ticketPrice) + "\n");
                        writer.write("NUMBER OF TICKETS: " + numberOfTickets + "\n");
                        writer.write("TOTAL TICKET PRICE (with VAT): R " + MovieTickets.formatCurrency(totalPrice));
                        JOptionPane.showMessageDialog(frame, "Report saved to report.txt", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(frame, "Error saving report", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter valid data (positive integers and prices).", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        clearMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ticketsTextField.setText("");
                priceTextField.setText("");
                reportTextArea.setText("");
            }
        });
    }
}
